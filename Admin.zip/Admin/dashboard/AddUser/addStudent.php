<!-- -------------------------- -->
<?php
  session_start(); 
  if(!isset($_SESSION['adminID'])){
    header('location: ../../../admin_login.php');
    exit();
  } 
  $fullName = '';
  $password = '';
  $new_user_id;

  if(isset($_GET['add-student'])){

    $user_id = $_GET['add-student'];
    $new_user_id = $user_id;
    require '../Backend/User/view_all_users.php';
    $users = new ViewUsers();
    $row =  $users->viewAllUsers();
    for($i = 0; $i<count($row); $i++){
      if($row[$i]['user_id'] == $user_id){
        $fullName = $row[$i]['user_fullName'];
        $password = $row[$i]['user_password'];
      }
    }

  }

?>
<!-- -------------------------- -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Admin - Student Add Panel</title>
  <!-- Favicon -->
  <link href="../assets/img/brand/favicon.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="../assets/js/plugins/nucleo/css/nucleo.css" rel="stylesheet" />
  <link href="../assets/js/plugins/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="../assets/css/argon-dashboard.css?v=1.1.2" rel="stylesheet" />
  <style>
    @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+JP&display=swap');
    /* font-family: 'IBM Plex Sans JP', sans-serif; */
    .new-font{font-family: 'IBM Plex Sans JP', sans-serif;}
    div.online-indicator {
      display: inline-block;
      width: 15px;
      height: 15px;
      margin-right: 10px;
      
      background-color: #0fcc45;
      border-radius: 50%;
      
      position: relative;
    }
    span.blink {
      display: block;
      width: 15px;
      height: 15px;
      
      background-color: #0fcc45;
      opacity: 0.7;
      border-radius: 50%;
      
      animation: blink 1s linear infinite;
    }
    /*Animations*/

    @keyframes blink {
      100% { transform: scale(2, 2); 
              opacity: 0;
            }
    }
  </style>
</head>

<body class="">
  <nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-white" id="sidenav-main">
    <div class="container-fluid">
      <!-- Toggler -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <!-- Brand -->
      <a class="pt-0" href="./index.php">
        <center>
        <img style="width: 50%; height:50;" src="../assets/img/theme/kou-logo.png"  alt="...">
        </center>
      </a>
      <!-- User -->
      <ul class="nav align-items-center d-md-none">
        <li class="nav-item dropdown">
          <a class="nav-link nav-link-icon" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="ni ni-bell-55"></i>
          </a>
          <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right" aria-labelledby="navbar-default_dropdown_1">
            <a class="dropdown-item" href="#">Notification</a>
            <a class="dropdown-item" href="#">Notification</a>
            <a class="dropdown-item" href="#">Notification</a>
          </div>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <div class="media align-items-center">
              <span class="avatar avatar-sm rounded-circle">
                <img alt="Image placeholder" src="../assets/img/theme/man.jpg">
              </span>
            </div>
          </a>
          <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
          <div class=" dropdown-header noti-title">
              <h6 class="text-overflow m-0">Welcome!</h6>
            </div>
            <a href="Profilee.php" class="dropdown-item">
              <i class="ni ni-single-02"></i>
              <span>Profilee</span>
            </a>
            <a href="./Profilee.php" class="dropdown-item">
              <i class="ni ni-settings-gear-65"></i>
              <span>Settings</span>
            </a>
            <a href="./Profilee.php" class="dropdown-item">
              <i class="ni ni-calendar-grid-58"></i>
              <span>Events</span>
            </a>
            <div class="dropdown-divider"></div>
            <span>
                    <?php
                        if(isset($_SESSION['adminID'])){
                          echo '<a href="../logout.php"><i class="ml-3 mr-2 ni ni-user-run"></i>Logout</a>';
                        }else{
                          echo 'Logout';
                        }
                    ?>
              </span>
          </div>
        </li>
      </ul>
      <!-- Collapse -->
      <div class="collapse navbar-collapse" id="sidenav-collapse-main">
        <!-- Collapse header -->
        <div class="navbar-collapse-header d-md-none">
          <div class="row">
            <div class="col-6 collapse-brand">
              <a href="../index.html">
              </a>
            </div>
            <div class="col-6 collapse-close">
              <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle sidenav">
                <span></span>
                <span></span>
              </button>
            </div>
          </div>
        </div>
        </form>
        <!-- Navigation -->
        <ul class="navbar-nav">
          <center>
            <h3 class="new-font">
            <div class="online-indicator">
              <span class="blink"></span>
            </div>
              <?php echo $_SESSION['admin_fullName']; ?></h3>
              <h5 class="new-font">
              <?php
                $admin_id = $_SESSION['adminID'];
                $connection = mysqli_connect('localhost','root','','yazgeldb1');
                $sql = "SELECT * FROM admin WHERE admin_id='$admin_id'";
                $res = mysqli_query($connection, $sql);
                while($row=mysqli_fetch_assoc($res)){
                  if($row['admin_type'] == 'super_admin'){
                    echo 'Super Admin';
                  }else{
                    echo 'Admin';
                  }
                }
              ?>
            </h5>
          </center>
          <li class="nav-item  active ">
            <a class="nav-link  active " href="../index.php">
              <i class="ni ni-tv-2 text-primary"></i> Home
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link " href="../examples/Profilee.php">
              <i class="ni ni-single-02 text-yellow"></i> Profilee
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../examples/register.php">
              <i class="ni ni-circle-08 text-pink"></i> Add User
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <div class="main-content">
    <!-- Navbar -->
    <nav class="navbar navbar-top navbar-expand-md navbar-dark" id="navbar-main">
      <div class="container-fluid">
        <!-- Brand -->
        <a class="h4 mb-0 text-uppercase d-none d-lg-inline-block" href="../index.php">Back to Home</a>
        </form>
        <!-- User -->
        <ul class="navbar-nav align-items-center d-none d-md-flex">
          <li class="nav-item dropdown">
            <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <div class="media align-items-center">
                <span class="avatar avatar-sm rounded-circle">
                  <img alt="Image placeholder" src="../assets/img/theme/man.jpg">
                </span>
                <div class="media-body ml-2 d-none d-lg-block">
                  <span style="color:black ;" class="mb-0 text-sm  font-weight-bold">
                    <?php
                        if(isset($_SESSION['adminID'])){
                            echo $_SESSION['admin_fullName'];
                        }else{
                          echo 'User';
                        }
                    ?>
                  </span>
                </div>
              </div>
            </a>
            <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
            <div class=" dropdown-header noti-title">
              <h6 class="text-overflow m-0">Welcome!</h6>
            </div>
            <a href="Profilee.php" class="dropdown-item">
              <i class="ni ni-single-02"></i>
              <span>Profilee</span>
            </a>
            <a href="./Profilee.php" class="dropdown-item">
              <i class="ni ni-settings-gear-65"></i>
              <span>Settings</span>
            </a>
            <a href="./Profilee.php" class="dropdown-item">
              <i class="ni ni-calendar-grid-58"></i>
              <span>Events</span>
            </a>
            <div class="dropdown-divider"></div>
            <span>
                    <?php
                        if(isset($_SESSION['adminID'])){
                          echo '<a href="../logout.php"><i class="ml-3 mr-2 ni ni-user-run"></i>Logout</a>';
                        }else{
                          echo 'Logout';
                        }
                    ?>
              </span>
            </div>
          </li>
        </ul>
      </div>
    </nav>
    <!-- End Navbar -->
    <!-- Header -->
    <div class="header pb-8 pt-5 pt-lg-8 d-flex align-items-center" style="min-height: 100px;">
    </div>
    <div class="container-fluid mt--7">
        <center>
          <h1 class="new-font">Add Student Panel</h1>
        </center>
        <div class="order-xl-1">
          <div class="card bg-secondary shadow">
            <div class="card-header bg-white border-0">
              <div class="row align-items-center">
                <div class="col-8">
                  <h3 class="mb-0">New Account</h3>
                </div>
              </div>
            </div>
            <div class="card-body">
              <form method="post" action="add_student_post.php">
                <h6 class="heading-small text-muted mb-4">Student Information</h6>
                <div class="pl-lg-4">
                  <div class="row">
                    <!-- **************************************************** -->
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label" for="input-username">Full Name</label>
                        <input type="text" name="fullName" class="form-control form-control-alternative" placeholder="Full Name" value="<?php echo $fullName; ?>" required>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label" for="input-username">T.C</label>
                        <input type="text" name="tc" class="form-control form-control-alternative" placeholder="T.C Identity Number" required>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label" for="input-email">Nationality</label>
                        <input type="text" name="nationality" class="form-control form-control-alternative" value="Turkish" placeholder="Turkish" required>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label" for="input-username">Phone</label>
                        <input type="text" name="tel" class="form-control form-control-alternative" placeholder="+905XXXXXXXXX" required>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label" for="input-email">Email Address</label>
                        <input type="email" name="email" class="form-control form-control-alternative" placeholder="example@gmail.com" required>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label" for="input-email">Password</label>
                        <input type="password" name="password" class="form-control form-control-alternative" placeholder="Password" required>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label" for="input-email">University Name</label>
                        <input type="text" name="university" class="form-control form-control-alternative" value="Kocaeli" placeholder="Kocaeli" required>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label" for="input-email">Faculty</label>
                        <input type="text" name="faculty" class="form-control form-control-alternative" value="Technology" placeholder="Technology" required>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label" for="input-email">Department</label>
                        <input type="text" name="department" class="form-control form-control-alternative" value="Computer Engineering" placeholder="Computer Engineering" required>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label" for="input-email">Grade</label>
                        <input type="text" name="grade" class="form-control form-control-alternative" placeholder="Grade example: 2" required>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label" for="input-email">Student Number</label>
                        <input type="text" name="university_no" class="form-control form-control-alternative" placeholder="Student Number" required>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label" for="input-email">Home Address</label>
                        <input type="text" name="address" class="form-control form-control-alternative" placeholder="Address" required>
                      </div>
                    </div>
                    <!-- **************************************************** -->
                  </div>
                  <div class="row">
                    <div class="col-lg-12">
                        <button name="add-student-btn" value="<?php echo $new_user_id ?>" class="btn btn-success" type="submit">Add Student</button>
                    </div>
                  </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <!-- Footer -->
      <footer class="footer">
        <div class="row align-items-center justify-content-xl-between">
          <div class="col-xl-6">
            <div class="copyright text-center text-xl-left text-muted">
              &copy; 2022 <a href="#" class="font-weight-bold ml-1">KOÜ IT</a>
            </div>
          </div>
          <div class="col-xl-6">
            <ul class="nav nav-footer justify-content-center justify-content-xl-end">
              <li class="nav-item">
                <a href="#" class="nav-link">MIT License</a>
              </li>
            </ul>
          </div>
        </div>
      </footer>
    </div>
  </div>
  <!--   Core   -->
  <script src="../assets/js/plugins/jquery/dist/jquery.min.js"></script>
  <script src="../assets/js/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!--   Optional JS   -->
  <!--   Argon JS   -->
  <script src="../assets/js/argon-dashboard.min.js?v=1.1.2"></script>
  <script src="https://cdn.trackjs.com/agent/v3/latest/t.js"></script>
  <script>
    window.TrackJS &&
      TrackJS.install({
        token: "ee6fab19c5a04ac1a32a645abde4613a",
        application: "argon-dashboard-free"
      });
  </script>
</body>

</html>
