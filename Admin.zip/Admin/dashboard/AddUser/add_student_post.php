<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require './phpmailer/src/Exception.php';
require './phpmailer/src/PHPMailer.php';
require './phpmailer/src/SMTP.php';

if(isset($_POST['add-student-btn'])){

    $new_user_id = $_POST['add-student-btn'];
    $connection = mysqli_connect('localhost','root','','yazgeldb1');
    $sql = "DELETE FROM newuser WHERE user_id='$new_user_id'";
    mysqli_query($connection, $sql);
    $fullName = $_POST['fullName'];
    $tc = $_POST['tc'];
    $nationality = $_POST['nationality'];
    $tel = $_POST['tel'];
    $email =  $_POST['email'];
    $password = md5($_POST['password']);
    $university = $_POST['university'];
    $faculty = $_POST['faculty'];
    $department = $_POST['department'];
    $grade = $_POST['grade'];
    $university_no = $_POST['university_no'];
    $address = $_POST['address'];
    include '../Backend/Student/add_new_student.php';
    include '../Backend/Student/add_new_student_contr.php';
  
    $add_student = new AddNewStudentContr($fullName, $tc, $nationality, $tel, $email, $password, $university, $faculty, $department, $grade, $university_no, $address);
    $add_student->addStudent();
    
    // sending password to user's provided email
    $pwd = $_POST['password'];
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'nazirsharifi19@gmail.com';
    $mail->Password = 'wspaeyhlptuwqnwe';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;
    $mail->setFrom('nazirsharifi19@gmail.com');
    $mail->addAddress($_POST['email']);
    $mail->isHTML(true);
    $mail->Subject = 'KOU Internship Tracking New Account Password';
    $mail->Body = 'The student with university number ' . $university_no . ' has successfully created a KOU Internship Tracking account! <br>
    The account password is: <b>' . $pwd . '<b>';
    $mail->send();
    header('location: ../View/viewStudent.php?add-student=success');
}

