<?php
#
#
class Dbh{
    protected function connectDB(){
        try{
            $username = 'root';
            $password = '';
            $dbh = new PDO('mysql:host=localhost;dbname=yazgeldb1', $username, $password);
            return $dbh;
        }catch(PDOException $error){
            print 'Error: '. $error->getMessage() . '<br>';
            die();
        }
    }
}