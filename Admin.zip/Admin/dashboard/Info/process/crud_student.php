<?php

if(isset($_POST['update_student_info'])){

    $student_id = $_POST['update_student_info'];
    $fullName = $_POST['fullName'];
    $tc = $_POST['tc'];
    $nationality = $_POST['nationality'];
    $tel = $_POST['tel'];
    $email =  $_POST['email'];
    $password = $_POST['password'];
    $university = $_POST['university'];
    $faculty = $_POST['faculty'];
    $department = $_POST['department'];
    $grade = $_POST['grade'];
    $university_no = $_POST['university_no'];
    $address = $_POST['address'];
    /**/
    require '../../Backend/Student/update_student.php';
    $update_student_info = new UpdateStudent($fullName, $tc, $nationality, $tel, $email, $password, $university, $faculty, $department, $grade, $university_no, $address, $student_id);
    header('Location: ../../View/viewStudent.php?update=success');
    exit();
}

if(isset($_POST['remove_student'])){

    $student_id = $_POST['remove_student'];
    require '../../Backend/Student/remove_student.php';
    $remove_student = new RemoveStudent($student_id);

    $connection = mysqli_connect('localhost','root','','yazgeldb1');
    $sql =  "SELECT * FROM student WHERE kullanci_id='$student_id'";
    $result = mysqli_query($connection, $sql);
    while($row=mysqli_fetch_assoc($result)){
        $student_number = $row['ogrenci_okul_no'];
        $sql1 = "DELETE FROM staj_basvuru WHERE ogrenci_numarasi='$student_number'";
        mysqli_query($connection, $sql1);
        $sql2 = "DELETE from Internship_Tracking WHERE ogrenci_numarasi='$student_number'";
        mysqli_query($connection, $sql2);
        $sql3 = "DELETE from staj_belgerli WHERE ogrenci_numarasi='$student_number'";
        mysqli_query($connection, $sql3);
        $sql4 = "DELETE from staj_kabul_belgesi WHERE ogrenci_numarasi='$student_number'";
        mysqli_query($connection, $sql4);
        $sql5 = "DELETE from staj_raporu WHERE ogrenci_numarasi='$student_number'";
        mysqli_query($connection, $sql5);

        // 
        $sql6 = "DELETE from ime_basvuru WHERE ogrenci_numarasi='$student_number'";
        mysqli_query($connection, $sql6);
        $sql7 = "DELETE from ime_takibi WHERE ogrenci_numarasi='$student_number'";
        mysqli_query($connection, $sql7);
        $sql8 = "DELETE from ime_belgeleri WHERE ogrenci_numarasi='$student_number'";
        mysqli_query($connection, $sql8);
        $sql9 = "DELETE from ime_kabul_belgesi WHERE ogrenci_numarasi='$student_number'";
        mysqli_query($connection, $sql9);

    }
    header('Location: ../../View/viewStudent.php?student-remove=success');
    exit();

}