<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Read Excel Docs</title>
</head>
<body>
    <?php
    /*
        include 'vendor/autoload.php';
        use PhpOffice\PhpSpreadsheet\Reader\Xlsx;
        $reader = new Xlsx();
        $spreadsheet = $reader->load(__DIR__ . '/list.xlsx');
        $sheetData = $spreadsheet->getActiveSheet()->toArray();
        $connection = mysqli_connect('localhost','root','','yazgeldb');
        for($i = 1; $i<count($sheetData); $i++){
            $student_number = $sheetData[$i][0];
            $student_firstName = $sheetData[$i][1];
            $student_lastName = $sheetData[$i][2];
            $student_fullName = $student_firstName.' '.$student_lastName;
            $student_email = $sheetData[$i][3];
            $student_tc = $sheetData[$i][4];
            $student_nationality = $sheetData[$i][5];
            $student_tel = $sheetData[$i][6];
            $student_password = md5($sheetData[$i][7]);
            $student_university = $sheetData[$i][8];
            $student_faculty = $sheetData[$i][9];
            $student_department = $sheetData[$i][10];
            $student_class = $sheetData[$i][11];
            $student_address = $sheetData[$i][12];
            $sql ="INSERT INTO student(ogrenci_ad_soyad, ogrenci_tc, ogrenci_uyrugu, ogrenci_tel, ogrenci_mail,ogrenci_password, ogrenci_okul_adi, ogrenci_fakulte_adi, ogrenci_bolumm_adi, ogrenci_sinif, ogrenci_okul_no, ogrenci_address) VALUES('$student_fullName','$student_tc','$student_nationality','$student_tel','$student_email','$student_password','$student_university','$student_faculty','$student_department','$student_class','$student_number','$student_address')";
            mysqli_query($connection, $sql);
        }
        */
        
    ?>
</body>
</html>