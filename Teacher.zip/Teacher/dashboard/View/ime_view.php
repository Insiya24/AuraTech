<?php 
  session_start();
  if(!isset($_SESSION['teacher_id'])){
    header('location: ../../teacher_login.php');
    exit();
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Öğretmen -İME View</title>
  <!-- Favicon -->
  <link href="../assets/img/brand/favicon.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="../assets/js/plugins/nucleo/css/nucleo.css" rel="stylesheet" />
  <link href="../assets/js/plugins/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="../assets/css/argon-dashboard.css?v=1.1.2" rel="stylesheet" />
  <style>
    @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+JP&display=swap');
    /* font-family: 'IBM Plex Sans JP', sans-serif; */
    .new-font{font-family: 'IBM Plex Sans JP', sans-serif;}
    div.online-indicator {
      display: inline-block;
      width: 15px;
      height: 15px;
      margin-right: 10px;
      
      background-color: #0fcc45;
      border-radius: 50%;
      
      position: relative;
    }
    span.blink {
      display: block;
      width: 15px;
      height: 15px;
      
      background-color: #0fcc45;
      opacity: 0.7;
      border-radius: 50%;
      
      animation: blink 1s linear infinite;
    }
    /*Animations*/

    @keyframes blink {
      100% { transform: scale(2, 2); 
              opacity: 0;
            }
    }
  </style>
</head>

<body class="">
  <nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-white" id="sidenav-main">
    <div class="container-fluid">
      <!-- Toggler -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <!-- Brand -->
      <a class="pt-0" href="./index.php">
        <center>
        <img style="width: 50%; height:50;" src="../assets/img/theme/kou-logo.png"  alt="...">
        </center>
      </a>
      <!-- User -->
      <ul class="nav align-items-center d-md-none">
        <li class="nav-item dropdown">
          <a class="nav-link nav-link-icon" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="ni ni-bell-55"></i>
          </a>
          <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right" aria-labelledby="navbar-default_dropdown_1">
            <a class="dropdown-item" href="#">Action</a>
            <a class="dropdown-item" href="#">Another action</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#">Something else here</a>
          </div>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <div class="media align-items-center">
              <span class="avatar avatar-sm rounded-circle">
                <img alt="Image placeholder" src="../assets/img/theme/man.jpg">
              </span>
            </div>
          </a>
          <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
          <div class=" dropdown-header noti-title">
              <h6 class="text-overflow m-0">Welcome!</h6>
            </div>
            <a href="../examples/Profilee.php" class="dropdown-item">
              <i class="ni ni-single-02"></i>
              <span>Profile</span>
            </a>
            <a href="../examples/Profilee.php" class="dropdown-item">
              <i class="ni ni-settings-gear-65"></i>
              <span>Settings</span>
            </a>
            <a href="../examples/Profilee.php" class="dropdown-item">
              <i class="ni ni-calendar-grid-58"></i>
              <span>Events</span>
            </a>
            <div class="dropdown-divider"></div>
            <span>
                    <?php
                        if(isset($_SESSION['teacher_id'])){
                          echo '<a href="../logout.php"><i class="ml-3 mr-2 ni ni-user-run"></i>Logout</a>';
                        }else{
                          echo 'Logout';
                        }
                    ?>
              </span>
          </div>
        </li>
      </ul>
      <!-- Collapse -->
      <div class="collapse navbar-collapse" id="sidenav-collapse-main">
        <!-- Collapse header -->
        <div class="navbar-collapse-header d-md-none">
          <div class="row">
            <div class="col-6 collapse-brand">
              <a href="../index.php">
                
              </a>
            </div>
            <div class="col-6 collapse-close">
              <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle sidenav">
                <span></span>
                <span></span>
              </button>
            </div>
          </div>
        </div>
        </form>
        <!-- Navigation -->
        <ul class="navbar-nav">
          <center>
            <h4 class="new-font">
            <div class="online-indicator">
              <span class="blink"></span>
            </div>
              <?php echo $_SESSION['teacher_name']; ?></h4>
            <h5 class="new-font">Teacher Member</h5>
          </center>
          <li class="nav-item  active ">
            <a class="nav-link  active " href="../index.php">
              <i class="ni ni-tv-2 text-primary"></i> Home
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link " href="../examples/Profilee.php">
              <i class="ni ni-single-02 text-yellow"></i> Profile
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <div class="main-content">
    <!-- Navbar -->
    <nav class="navbar navbar-top navbar-expand-md navbar-dark" id="navbar-main">
      <div class="container-fluid">
        <!-- Brand -->
        <a class="h4 mb-0 text-uppercase d-none d-lg-inline-block" href="../index.php">Return to Home</a>
        </form>
        <!-- User -->
        <ul class="navbar-nav align-items-center d-none d-md-flex">
          <li class="nav-item dropdown">
            <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <div class="media align-items-center">
                <span class="avatar avatar-sm rounded-circle">
                  <img alt="Image placeholder" src="../assets/img/theme/man.jpg">
                </span>
                <div class="media-body ml-2 d-none d-lg-block">
                  <span style="color:black ;" class="mb-0 text-sm  font-weight-bold">
                    <?php
                        if(isset($_SESSION['teacher_id'])){
                          echo $_SESSION['teacher_name'];
                        }else{
                          echo 'User';
                        }
                    ?>
                  </span>
                </div>
              </div>
            </a>
            <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
              <div class=" dropdown-header noti-title">
                <h6 class="text-overflow m-0">Welcome</h6>
              </div>
              <a href="../examples/Profilee.php" class="dropdown-item">
                <i class="ni ni-single-02"></i>
                <span>Profile</span>
              </a>
              <a href="../examples/Profilee.php" class="dropdown-item">
                <i class="ni ni-settings-gear-65"></i>
                <span>Settings</span>
              </a>
              <a href="../examples/Profilee.php" class="dropdown-item">
                <i class="ni ni-calendar-grid-58"></i>
                <span>Events</span>
              </a>
              <div class="dropdown-divider"></div>
              <span>
                    <?php
                        if(isset($_SESSION['teacher_id'])){
                          echo '<a href="../logout.php"><i class="ml-3 mr-2 ni ni-user-run"></i>Logout</a>';
                        }else{
                          echo 'Logout';
                        }
                    ?>
              </span>
            </div>
          </li>
        </ul>
      </div>
    </nav>
    <!-- End Navbar -->

    <!-- ------------------------------------------------------------------------------------------------------------- -->
    <div class="header pb-4 pt-2 pt-lg-8 d-flex align-items-center">
        <div class="container">
        <center>
          <h1 class="new-font mb-4">İME Öğrenci Listesi <i style="color: green;" class="fas fa-info-circle"></i></h1>
        </center>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Ad Soyad</th>
                        <th scope="col">Öğrenci NO</th>
                        <th scope="col">Durum</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $connection = mysqli_connect('localhost', 'root','','yazgeldb1');
                        $teacher_number = $_SESSION['teacher_number'];
                        $sql = "SELECT ogrenci_numarasi FROM ime_takibi WHERE ogretmen_numarasi='$teacher_number'";
                        $result = mysqli_query($connection, $sql);
                        if(mysqli_num_rows($result) == 0){
                            echo '<h2 class="new-font" style="text-align:center; color:green;">No result found!</h2>';
                        }else{
                            while($row=mysqli_fetch_assoc($result)){

                                $student_number = $row['ogrenci_numarasi'];
                                $new_sql = "SELECT * FROM student WHERE ogrenci_okul_no='$student_number' ";
                                $new_result = mysqli_query($connection, $new_sql);

                                while($new_row=mysqli_fetch_assoc($new_result)){
                    ?>
                                    <tr>
                                        <th scope="row">1</th>
                                        <td><?php echo $new_row['ogrenci_ad_soyad']; ?></td>
                                        <td><?php echo $new_row['ogrenci_okul_no']; ?></td>
                                        <td>
                                            <button class="btn btn-primary"><a style="color:#fff ;" href="view-ime-student-info.php?view-student-info=<?php echo $new_row['kullanci_id'];?>">view</a></button>
                                            <button class="btn btn-success"><a style="color:#fff ;" href="ime_notlandir.php?view-student-info=<?php echo $new_row['kullanci_id'];?>">Notlandır</a></button>
                                          </td>
                                    </tr>
                    <?php
                                }
                            }
                        }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- -------------------------------------------------------------------------------------------------------------- -->
      <!-- Footer -->
      <footer class="footer">
        <div class="row align-items-center justify-content-xl-between">
          <div class="col-xl-6">
            <div class="copyright text-center text-xl-left text-muted">
              &copy; 2022 <a href="#" class="font-weight-bold ml-1">KOÜ Bilişim</a>
            </div>
          </div>
          <div class="col-xl-6">
            <ul class="nav nav-footer justify-content-center justify-content-xl-end">
              <li class="nav-item">
                <a href="#" class="nav-link">MIT License</a>
              </li>
            </ul>
          </div>
        </div>
      </footer>
    </div>
  </div>
  <!--   Core   -->
  <script src="../assets/js/plugins/jquery/dist/jquery.min.js"></script>
  <script src="../assets/js/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!--   Optional JS   -->
  <!--   Argon JS   -->
  <script src="../assets/js/argon-dashboard.min.js?v=1.1.2"></script>
  <script src="https://cdn.trackjs.com/agent/v3/latest/t.js"></script>
  <script>
    window.TrackJS &&
      TrackJS.install({
        token: "ee6fab19c5a04ac1a32a645abde4613a",
        application: "argon-dashboard-free"
      });
  </script>
</body>

</html>