<?php 
  session_start();
  if(!isset($_SESSION['teacher_id'])){
    header('location:../../../teacher_login.php');
    exit();
  }
?>
<?php
  if(isset($_POST['staj-basarili-btn'])){
    $student_number = $_POST['staj-basarili-btn'];
    $teacher_number = $_SESSION['teacher_number'];
    $feedback = $_POST['feedback'];

    $connection = mysqli_connect('localhost','root','','yazgeldb1');
    $sql = "UPDATE Internship_Tracking SET staj_durumu='done', geri_Notification='$feedback', Teacher_numarasi='$teacher_number'   WHERE ogrenci_numarasi='$student_number' AND staj_tur='staj1'";
    mysqli_query($connection, $sql);
    header('Location: internship2_view.php');
    exit();
  }

  if(isset($_POST['eksik-belge-btn'])){
    $student_number = $_POST['eksik-belge-btn'];
    $teacher_number = $_SESSION['teacher_number'];
    $feedback = $_POST['feedback'];
    header('Location: internship1_view.php');
    exit();

    $connection = mysqli_connect('localhost','root','','yazgeldb1');
    $sql = "UPDATE Internship_Tracking SET staj_durumu='eksik_belge', geri_Notification='$feedback', Teacher_numarasi='$teacher_number'   WHERE ogrenci_numarasi='$student_number' AND staj_tur='staj1'";
    mysqli_query($connection, $sql);
    header('Location: internship1_view.php');
    exit();
  }
  if(isset($_POST['staj-basarisiz-btn'])){
    $student_number = $_POST['staj-basarisiz-btn'];
    $teacher_number = $_SESSION['teacher_number'];
    $feedback = $_POST['feedback'];

    $connection = mysqli_connect('localhost','root','','yazgeldb1');
    $sql = "UPDATE Internship_Tracking SET staj_durumu='basarisiz', geri_Notification='$feedback', Teacher_numarasi='$teacher_number'   WHERE ogrenci_numarasi='$student_number' AND staj_tur='staj1'";
    mysqli_query($connection, $sql);
    header('Location: internship1_view.php');
    exit();
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Öğretmen -Staj 1 Notlandırması</title>
  <!-- Favicon -->
  <link href="../assets/img/brand/favicon.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="../assets/js/plugins/nucleo/css/nucleo.css" rel="stylesheet" />
  <link href="../assets/js/plugins/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="../assets/css/argon-dashboard.css?v=1.1.2" rel="stylesheet" />
</head>

<body class="">
  <nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-white" id="sidenav-main">
    <div class="container-fluid">
      <!-- Toggler -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <!-- Brand -->
      <a class="pt-0" href="./index.php">
        <center>
        <img style="width: 50%; height:50;" src="../assets/img/theme/kou-logo.png"  alt="...">
        </center>
      </a>
      <!-- User -->
      <ul class="nav align-items-center d-md-none">
        <li class="nav-item dropdown">
          <a class="nav-link nav-link-icon" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="ni ni-bell-55"></i>
          </a>
          <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right" aria-labelledby="navbar-default_dropdown_1">
            <a class="dropdown-item" href="#">Action</a>
            <a class="dropdown-item" href="#">Another action</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#">Something else here</a>
          </div>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <div class="media align-items-center">
              <span class="avatar avatar-sm rounded-circle">
                <img alt="Image placeholder" src="../assets/img/theme/man.jpg">
              </span>
            </div>
          </a>
          <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
          <div class=" dropdown-header noti-title">
              <h6 class="text-overflow m-0">Welcome!</h6>
            </div>
            <a href="../examples/Profilee.php" class="dropdown-item">
              <i class="ni ni-single-02"></i>
              <span>Profile</span>
            </a>
            <a href="../examples/Profilee.php" class="dropdown-item">
              <i class="ni ni-settings-gear-65"></i>
              <span>Settings</span>
            </a>
            <a href="../examples/Profilee.php" class="dropdown-item">
              <i class="ni ni-calendar-grid-58"></i>
              <span>Events</span>
            </a>
            <div class="dropdown-divider"></div>
            <span>
                    <?php
                        if(isset($_SESSION['teacher_id'])){
                          echo '<a href="../logout.php"><i class="ml-3 mr-2 ni ni-user-run"></i>Logout</a>';
                        }else{
                          echo 'Logout';
                        }
                    ?>
              </span>
          </div>
        </li>
      </ul>
      <!-- Collapse -->
      <div class="collapse navbar-collapse" id="sidenav-collapse-main">
        <!-- Collapse header -->
        <div class="navbar-collapse-header d-md-none">
          <div class="row">
            <div class="col-6 collapse-brand">
              <a href="../index.php">
              </a>
            </div>
            <div class="col-6 collapse-close">
              <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle sidenav">
                <span></span>
                <span></span>
              </button>
            </div>
          </div>
        </div>
        </form>
        <!-- Navigation -->
        <ul class="navbar-nav">
          <center>
            <h4 class="new-font">
            <div class="online-indicator">
              <span class="blink"></span>
            </div>
              <?php echo $_SESSION['teacher_name']; ?></h4>
            <h5 class="new-font">Teacher Member</h5>
          </center>
          <li class="nav-item  active ">
            <a class="nav-link  active " href="../index.php">
              <i class="ni ni-tv-2 text-primary"></i> Home
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link " href="../examples/Profilee.php">
              <i class="ni ni-single-02 text-yellow"></i> Profile
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <div class="main-content">
    <!-- Navbar -->
    <nav class="navbar navbar-top navbar-expand-md navbar-dark" id="navbar-main">
      <div class="container-fluid">
        <!-- Brand -->
        <a class="h4 mb-0 text-uppercase d-none d-lg-inline-block" href="../index.php">Return to Home</a>
        </form>
        <!-- User -->
        <ul class="navbar-nav align-items-center d-none d-md-flex">
          <li class="nav-item dropdown">
            <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <div class="media align-items-center">
                <span class="avatar avatar-sm rounded-circle">
                  <img alt="Image placeholder" src="../assets/img/theme/man.jpg">
                </span>
                <div class="media-body ml-2 d-none d-lg-block">
                  <span style="color:black;" class="mb-0 text-sm  font-weight-bold">
                    <?php
                        if(isset($_SESSION['teacher_id'])){
                          echo $_SESSION['teacher_name'];
                        }else{
                          echo 'User';
                        }
                    ?>
                  </span>
                </div>
              </div>
            </a>
            <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
            <div class=" dropdown-header noti-title">
                <h6 class="text-overflow m-0">Welcome</h6>
              </div>
              <a href="../examples/Profilee.php" class="dropdown-item">
                <i class="ni ni-single-02"></i>
                <span>Profile</span>
              </a>
              <a href="../examples/Profilee.php" class="dropdown-item">
                <i class="ni ni-settings-gear-65"></i>
                <span>Settings</span>
              </a>
              <a href="../examples/Profilee.php" class="dropdown-item">
                <i class="ni ni-calendar-grid-58"></i>
                <span>Events</span>
              </a>
              <div class="dropdown-divider"></div>
              <span>
                    <?php
                        if(isset($_SESSION['teacher_id'])){
                          echo '<a href="../logout.php"><i class="ml-3 mr-2 ni ni-user-run"></i>Logout</a>';
                        }else{
                          echo 'Logout';
                        }
                    ?>
              </span>
            </div>
          </li>
        </ul>
      </div>
    </nav>
    <!-- End Navbar -->

    <!-- ------------------------------------------------------------------------------------------------------------- -->
    <div class="header pb-4 pt-2 pt-lg-8 d-flex align-items-center">
        <div class="container">
        <center>
          <h1 class="new-font mb-4">Staj 1 Öğrenci Notlandırması <i style="color: green;" class="fas fa-info-circle"></i></h1>
        </center>
            <table class="table">
                <tbody>
                    <?php
                    if(isset($_GET['view-student-info'])){
                        $student_id = $_GET['view-student-info'];
                        $connection = mysqli_connect('localhost', 'root','','yazgeldb1');
                        $sql = "SELECT * FROM student WHERE kullanci_id='$student_id'";
                        $result = mysqli_query($connection, $sql);
                        while($row=mysqli_fetch_assoc($result)){
                    ?>
                        <tr>
                            <td><b>Ad Soyad:</b></td>
                            <td><?php echo $row['ogrenci_ad_soyad'];?></td>
                            <td><b>Öğrenci Numarası:</b></td>
                            <td><?php echo $row['ogrenci_okul_no'] ?></td>

                        </tr>
                        <tr>
                            <td><b>Fakülte Adı: </b></td>
                            <td><?php echo $row['ogrenci_fakulte_adi'] ?></td>
                            <td><b>Bölüm Adı: </b></td>
                            <td><?php echo $row['ogrenci_bolumm_adi'] ?></td>
                        </tr>
                        <tr>
                            <td><b>Sınıf: </b></td>
                            <td><?php echo $row['ogrenci_sinif'] ?></td>
                            <td><b>Mail Adresi: </b></td>
                            <td><?php echo $row['ogrenci_mail'] ?></td>
                        </tr>
                    <?php
                        $student_number = $row['ogrenci_okul_no'];
                        $new_sql = "SELECT * FROM staj_basvuru WHERE basvuru_turu='staj1' AND ogrenci_numarasi='$student_number'";
                        $res = mysqli_query($connection, $new_sql);
                        while($new_row=mysqli_fetch_assoc($res)){
                    ?>
                            <tr>
                                <td><b>Staj Başlama Tarihi: </b></td>
                                <td><?php echo $new_row['baslama_tarihi'] ?></td>
                                <td><b>Staj Bitiş Tarihi: </b></td>
                                <td><?php echo $new_row['bitis_tarihi'] ?></td>
                            </tr>
                            <tr>
                                <td><b>İş Günü: </b></td>
                                <td><?php echo $new_row['is_gunu'] ?></td>
                                <td><b>Staj Yapılacak Kurum Adı: </b></td>
                                <td><?php echo $new_row['firma_adi'] ?></td>
                            </tr>
                            <tr>
                                <td><b>Staj Yapılacak Kurum'un Mail Adresi: </b></td>
                                <td><?php echo $new_row['firma_email'] ?></td>
                            </tr>
                            <tr>
                              <td><b>Staj Durumu:</b></td>
                              <td>
                                <b>
                                <?php
                                    $sql2 = "SELECT staj_durumu FROM Internship_Tracking WHERE ogrenci_numarasi='$student_number' AND staj_tur='staj1'";
                                    $res2 = mysqli_query($connection, $sql2);
                                    while($row2 = mysqli_fetch_assoc($res2)){
                                      echo $row2['staj_durumu'];
                                    }
                                ?>
                                </b>
                              </td>
                            </tr>
                            <tr>
                              <td><b>Staj Kabul Belgesi:</b></td>
                            </tr>
                            <tr>
                              <td colspan="3">
                                <?php
                                    $student_num = $row['ogrenci_okul_no'];
                                    $file_sql = "SELECT ogrenci_staj_kabul_belgesi FROM staj_kabul_belgesi WHERE ogrenci_numarasi='$student_num' AND staj_turu='staj1'";
                                    $file_result = mysqli_query($connection, $file_sql);
                                    if(mysqli_num_rows($file_result)== 0){
                                    ?>
                                        <div class="alert alert-danger" role="alert">Staj Kabul Belgesi Yüklenmemiştir!</div>
                                    <?php
                                    }else{
                                      while($file_row = mysqli_fetch_assoc($file_result)){
                                ?>
                                      <embed src="../../../Student/dashboard/Internship/uploads/<?php echo $file_row['ogrenci_staj_kabul_belgesi'] ?>" width="1100" height="400" type="application/pdf">
                                <?php
                                      }
                                    }
                                ?>
                              </td>
                            </tr>
                            <tr>
                              <td><b>Staj Raporu</b></td>
                            </tr>
                            <tr>
                              <td colspan="3">
                                  <?php
                                      $student_num = $row['ogrenci_okul_no'];
                                      $file_sql = "SELECT staj_raporu FROM staj_belgeleri WHERE ogrenci_numarasi='$student_num' AND staj_turu='staj1'";
                                      $file_result = mysqli_query($connection, $file_sql);
                                      if(mysqli_num_rows($file_result)== 0){
                                      ?>
                                          <div class="alert alert-danger" role="alert">Staj Raporu Henüz Yüklenmemiştir!</div>
                                      <?php
                                      }else{
                                        while($file_row = mysqli_fetch_assoc($file_result)){
                                  ?>
                                        <embed src="../../../Student/dashboard/Internship/Internship_docs/<?php echo $file_row['staj_raporu'] ?>" width="1100" height="400" type="application/pdf">
                                  <?php
                                        }
                                      }
                                  ?>
                                </td>
                            </tr>
                            <tr>
                              <td><b>Staj Değerlendirme Formu</b></td>
                            </tr>
                            <tr>
                              <td colspan="3">
                                  <?php
                                      $student_num = $row['ogrenci_okul_no'];
                                      $file_sql = "SELECT staj_degerlendirme_formu FROM staj_belgeleri WHERE ogrenci_numarasi='$student_num' AND staj_turu='staj1'";
                                      $file_result = mysqli_query($connection, $file_sql);
                                      if(mysqli_num_rows($file_result)== 0){
                                      ?>
                                          <div class="alert alert-danger" role="alert">Staj Değerlendirme Formu Henüz Yüklenmemiştir!</div>
                                      <?php
                                      }else{
                                        while($file_row = mysqli_fetch_assoc($file_result)){
                                  ?>
                                        <embed src="../../../Student/dashboard/Internship/Internship_docs/<?php echo $file_row['staj_degerlendirme_formu']; ?>" width="1100" height="400" type="application/pdf">
                                  <?php
                                        }
                                      }
                                  ?>
                                </td>
                            </tr>
                            <tr>
                              <td>
                              <?php
                              $student_number = $row['ogrenci_okul_no'];
                              $sql4 = "SELECT staj_durumu FROM Internship_Tracking WHERE staj_tur='staj1' AND ogrenci_numarasi='$student_number'";
                              $result4 = mysqli_query($connection, $sql4);
                              while($row4 = mysqli_fetch_assoc($result4)){
                                if($row4['staj_durumu'] == 'done'){
                            ?>
                              <button disabled type="submit" name="staj-basarili-btn" value="<?php echo $student_num  ?>" class="btn btn-success">Staj  Başarıyla Sonlandırıdı</button>
                            <?php
                                }elseif($row4['staj_durumu'] == 'basarisiz'){
                            ?>
                                <button disabled type="submit" name="staj-basarisiz-btn" value="<?php echo $student_num  ?>" class="btn btn-danger">Staj'ı Başarısızlıkla Sonlandırın</button>
                            <?php
                                }else{
                            ?>
                                <form action="./staj1_notlandir.php" method="post">
                                <tr>
                                    <td colspan="3">
                                        <input name="feedback" type="text" class="form-control" placeholder="Öğrenci'ye geri Notification yaz" required>
                                    </td>
                                </tr>
                                <tr>
                                  <td>
                                    <button type="submit" name="staj-basarili-btn" value="<?php echo $student_num  ?>" class="btn btn-success">Staj'ı Başarıyla Sonlandırın</button>
                                    <button type="submit" name="eksik-belge-btn" value="<?php echo $student_num  ?>" class="btn btn-info">Eksik Belge</button>
                                    <button type="submit" name="staj-basarisiz-btn" value="<?php echo $student_num  ?>" class="btn btn-outline-danger">Staj'ı Başarısızlıkla Sonlandırın</button>
                                  </td>
                                </tr>
                            </form>
                            <?php
                                }
                              }
                            ?>
                              </td>
                            </tr>
                            <?php
                              }
                          }
                      ?>
                    <?php
                        }
                    ?>
                    </form>
                </tbody>
            </table>
        </div>
    </div>
    <!-- 'done','devam_etmekte','degerlendirme','yeni_basvuru' -->
    <!-- -------------------------------------------------------------------------------------------------------------- -->
      <!-- Footer -->
      <footer class="footer">
        <div class="row align-items-center justify-content-xl-between">
          <div class="col-xl-6">
            <div class="copyright text-center text-xl-left text-muted">
              &copy; 2022 <a href="#" class="font-weight-bold ml-1">KOÜ Bilişim</a>
            </div>
          </div>
          <div class="col-xl-6">
            <ul class="nav nav-footer justify-content-center justify-content-xl-end">
              <li class="nav-item">
                <a href="#" class="nav-link">MIT License</a>
              </li>
            </ul>
          </div>
        </div>
      </footer>
    </div>
  </div>
  <!--   Core   -->
  <script src="../assets/js/plugins/jquery/dist/jquery.min.js"></script>
  <script src="../assets/js/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!--   Optional JS   -->
  <!--   Argon JS   -->
  <script src="../assets/js/argon-dashboard.min.js?v=1.1.2"></script>
  <script src="https://cdn.trackjs.com/agent/v3/latest/t.js"></script>
  <script>
    window.TrackJS &&
      TrackJS.install({
        token: "ee6fab19c5a04ac1a32a645abde4613a",
        application: "argon-dashboard-free"
      });
  </script>
</body>

</html>