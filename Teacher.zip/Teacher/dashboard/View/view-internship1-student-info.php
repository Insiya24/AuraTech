<?php 
  session_start();
  if(!isset($_SESSION['teacher_id'])){
    header('location:../../../teacher_login.php');
    exit();
  }
?>
<?php
  if(isset($_POST['staj-onayla-btn'])){
    $student_number = $_POST['staj-onayla-btn'];
    $teacher_number = $_SESSION['teacher_number'];
    $feedback = $_POST['feedback'];

    $connection = mysqli_connect('localhost','root','','yazgeldb1');
    $sql = "UPDATE Internship_Tracking SET staj_durumu='onaylandi', geri_Notification='Staj Basvurunuz onaylandi', Teacher_numarasi='$teacher_number'   WHERE ogrenci_numarasi='$student_number' AND staj_tur='staj1'";
    mysqli_query($connection, $sql);
  }

  if(isset($_POST['staj-red-btn'])){
    $student_number = $_POST['staj-red-btn'];
    $teacher_number = $_SESSION['teacher_number'];
    $feedback = $_POST['feedback'];
    header('location: internship1_view.php');
    exit();

    $connection = mysqli_connect('localhost','root','','yazgeldb1');
    $sql = "UPDATE Internship_Tracking SET staj_durumu='eksik_belge', geri_Notification='$feedback', Teacher_numarasi='$teacher_number'   WHERE ogrenci_numarasi='$student_number' AND staj_tur='staj1'";
    mysqli_query($connection, $sql);
    header('location: internship1_view.php');
    exit();
  }
  if(isset($_POST['staj-degerlendirme-btn'])){
    $student_number = $_POST['staj-degerlendirme-btn'];
    $teacher_number = $_SESSION['teacher_number'];
    $feedback = $_POST['feedback'];

    $connection = mysqli_connect('localhost','root','','yazgeldb1');
    $sql = "UPDATE Internship_Tracking SET staj_durumu='degerlendirme', geri_Notification='$feedback', Teacher_numarasi='$teacher_number'   WHERE ogrenci_numarasi='$student_number' AND staj_tur='staj1'";
    mysqli_query($connection, $sql);
    header('location: internship1_view.php');
    exit();
  }
  if(isset($_POST['staj-belge-yukleme-btn'])){
    $student_number = $_POST['staj-belge-yukleme-btn'];
    $teacher_number = $_SESSION['teacher_number'];
    $feedback = $_POST['feedback'];

    $connection = mysqli_connect('localhost','root','','yazgeldb1');
    $sql = "UPDATE Internship_Tracking SET staj_durumu='belge_yuklenmesi', geri_Notification='$feedback', Teacher_numarasi='$teacher_number'   WHERE ogrenci_numarasi='$student_number' AND staj_tur='staj1'";
    mysqli_query($connection, $sql);
    header('location: internship1_view.php');
    exit();
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Öğretmen -staj1 Öğrenci Bilgileri</title>
  <!-- Favicon -->
  <link href="../assets/img/brand/favicon.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="../assets/js/plugins/nucleo/css/nucleo.css" rel="stylesheet" />
  <link href="../assets/js/plugins/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="../assets/css/argon-dashboard.css?v=1.1.2" rel="stylesheet" />
  <style>
    @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+JP&display=swap');
    /* font-family: 'IBM Plex Sans JP', sans-serif; */
    .new-font{font-family: 'IBM Plex Sans JP', sans-serif;}
    div.online-indicator {
      display: inline-block;
      width: 15px;
      height: 15px;
      margin-right: 10px;
      
      background-color: #0fcc45;
      border-radius: 50%;
      
      position: relative;
    }
    span.blink {
      display: block;
      width: 15px;
      height: 15px;
      
      background-color: #0fcc45;
      opacity: 0.7;
      border-radius: 50%;
      
      animation: blink 1s linear infinite;
    }
    /*Animations*/

    @keyframes blink {
      100% { transform: scale(2, 2); 
              opacity: 0;
            }
    }
  </style>
</head>

<body class="">
  <nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-white" id="sidenav-main">
    <div class="container-fluid">
      <!-- Toggler -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <!-- Brand -->
      <a class="pt-0" href="./index.php">
        <center>
        <img style="width: 50%; height:50;" src="../assets/img/theme/kou-logo.png"  alt="...">
        </center>
      </a>
      <!-- User -->
      <ul class="nav align-items-center d-md-none">
        <li class="nav-item dropdown">
          <a class="nav-link nav-link-icon" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="ni ni-bell-55"></i>
          </a>
          <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right" aria-labelledby="navbar-default_dropdown_1">
            <a class="dropdown-item" href="#">Action</a>
            <a class="dropdown-item" href="#">Another action</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#">Something else here</a>
          </div>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <div class="media align-items-center">
              <span class="avatar avatar-sm rounded-circle">
                <img alt="Image placeholder" src="../assets/img/theme/man.jpg">
              </span>
            </div>
          </a>
          <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
          <div class=" dropdown-header noti-title">
              <h6 class="text-overflow m-0">Welcome!</h6>
            </div>
            <a href="../examples/Profilee.php" class="dropdown-item">
              <i class="ni ni-single-02"></i>
              <span>Profile</span>
            </a>
            <a href="../examples/Profilee.php" class="dropdown-item">
              <i class="ni ni-settings-gear-65"></i>
              <span>Settings</span>
            </a>
            <a href="../examples/Profilee.php" class="dropdown-item">
              <i class="ni ni-calendar-grid-58"></i>
              <span>Events</span>
            </a>
            <div class="dropdown-divider"></div>
            <span>
                    <?php
                        if(isset($_SESSION['teacher_id'])){
                          echo '<a href="../logout.php"><i class="ml-3 mr-2 ni ni-user-run"></i>Logout</a>';
                        }else{
                          echo 'Logout';
                        }
                    ?>
              </span>
            </a>
          </div>
        </li>
      </ul>
      <!-- Collapse -->
      <div class="collapse navbar-collapse" id="sidenav-collapse-main">
        <!-- Collapse header -->
        <div class="navbar-collapse-header d-md-none">
          <div class="row">
            <div class="col-6 collapse-brand">
              <a href="../index.php">
              </a>
            </div>
            <div class="col-6 collapse-close">
              <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle sidenav">
                <span></span>
                <span></span>
              </button>
            </div>
          </div>
        </div>
        </form>
        <!-- Navigation -->
        <ul class="navbar-nav">
          <center>
            <h4 class="new-font">
            <div class="online-indicator">
              <span class="blink"></span>
            </div>
              <?php echo $_SESSION['teacher_name']; ?></h4>
            <h5 class="new-font">Teacher Member</h5>
          </center>
          <li class="nav-item  active ">
            <a class="nav-link  active " href="../index.php">
              <i class="ni ni-tv-2 text-primary"></i> Home
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link " href="../examples/Profilee.php">
              <i class="ni ni-single-02 text-yellow"></i> Profile
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <div class="main-content">
    <!-- Navbar -->
    <nav class="navbar navbar-top navbar-expand-md navbar-dark" id="navbar-main">
      <div class="container-fluid">
        <!-- Brand -->
        <a class="h4 mb-0 text-uppercase d-none d-lg-inline-block" href="../index.php">Return to Home</a>
        </form>
        <!-- User -->
        <ul class="navbar-nav align-items-center d-none d-md-flex">
          <li class="nav-item dropdown">
            <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <div class="media align-items-center">
                <span class="avatar avatar-sm rounded-circle">
                  <img alt="Image placeholder" src="../assets/img/theme/man.jpg">
                </span>
                <div class="media-body ml-2 d-none d-lg-block">
                  <span style="color:black;" class="mb-0 text-sm  font-weight-bold">
                    <?php
                        if(isset($_SESSION['teacher_id'])){
                          echo $_SESSION['teacher_name'];
                        }else{
                          echo 'User';
                        }
                    ?>
                  </span>
                </div>
              </div>
            </a>
            <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
            <div class=" dropdown-header noti-title">
                <h6 class="text-overflow m-0">Welcome</h6>
              </div>
              <a href="../examples/Profilee.php" class="dropdown-item">
                <i class="ni ni-single-02"></i>
                <span>Profile</span>
              </a>
              <a href="../examples/Profilee.php" class="dropdown-item">
                <i class="ni ni-settings-gear-65"></i>
                <span>Settings</span>
              </a>
              <a href="../examples/Profilee.php" class="dropdown-item">
                <i class="ni ni-calendar-grid-58"></i>
                <span>Events</span>
              </a>
              <div class="dropdown-divider"></div>
              <span>
                    <?php
                        if(isset($_SESSION['teacher_id'])){
                          echo '<a href="../logout.php"><i class="ml-3 mr-2 ni ni-user-run"></i>Logout</a>';
                        }else{
                          echo 'Logout';
                        }
                    ?>
              </span>
            </div>
          </li>
        </ul>
      </div>
    </nav>
    <!-- End Navbar -->

    <!-- ------------------------------------------------------------------------------------------------------------- -->
    <div class="header pb-4 pt-2 pt-lg-8 d-flex align-items-center">
        <div class="container">
        <center>
          <h1 class="new-font mb-4">Staj 1 Öğrenci Bilgileri <i style="color: green;" class="fas fa-info-circle"></i></h1>
        </center>
            <table class="table">
                <tbody>
                    <?php
                    if(isset($_GET['view-student-info'])){
                        $student_id = $_GET['view-student-info'];
                        $connection = mysqli_connect('localhost', 'root','','yazgeldb1');
                        $sql = "SELECT * FROM student WHERE kullanci_id='$student_id'";
                        $result = mysqli_query($connection, $sql);
                        while($row=mysqli_fetch_assoc($result)){
                    ?>
                        <tr>
                            <td><b>Ad Soyad:</b></td>
                            <td><?php echo $row['ogrenci_ad_soyad'];?></td>
                            <td><b>Öğrenci Numarası:</b></td>
                            <td><?php echo $row['ogrenci_okul_no'] ?></td>

                        </tr>
                        <tr>
                            <td><b>Fakülte Adı: </b></td>
                            <td><?php echo $row['ogrenci_fakulte_adi'] ?></td>
                            <td><b>Bölüm Adı: </b></td>
                            <td><?php echo $row['ogrenci_bolumm_adi'] ?></td>
                        </tr>
                        <tr>
                            <td><b>Sınıf: </b></td>
                            <td><?php echo $row['ogrenci_sinif'] ?></td>
                            <td><b>Mail Adresi: </b></td>
                            <td><?php echo $row['ogrenci_mail'] ?></td>
                        </tr>
                    <?php
                        $student_number = $row['ogrenci_okul_no'];
                        $new_sql = "SELECT * FROM staj_basvuru WHERE basvuru_turu='staj1' AND ogrenci_numarasi='$student_number'";
                        $res = mysqli_query($connection, $new_sql);
                        while($new_row=mysqli_fetch_assoc($res)){
                    ?>
                            <tr>
                                <td><b>Staj Başlama Tarihi: </b></td>
                                <td><?php echo $new_row['baslama_tarihi'] ?></td>
                                <td><b>Staj Bitiş Tarihi: </b></td>
                                <td><?php echo $new_row['bitis_tarihi'] ?></td>
                            </tr>
                            <tr>
                                <td><b>İş Günü: </b></td>
                                <td><?php echo $new_row['is_gunu'] ?></td>
                                <td><b>Staj Yapılacak Kurum Adı: </b></td>
                                <td><?php echo $new_row['firma_adi'] ?></td>
                            </tr>
                            <tr>
                                <td><b>Staj Yapılacak Kurum'un Mail Adresi: </b></td>
                                <td><?php echo $new_row['firma_email'] ?></td>
                            </tr>
                            <tr>
                              <td><b>Staj Durumu:</b></td>
                              <td>
                                <b style="color: green;">
                                <?php
                                    $sql2 = "SELECT staj_durumu FROM Internship_Tracking WHERE ogrenci_numarasi='$student_number'";
                                    $res2 = mysqli_query($connection, $sql2);
                                    while($row2 = mysqli_fetch_assoc($res2)){
                                      echo $row2['staj_durumu'];
                                    }
                                ?>
                                </b>
                              </td>
                            </tr>
                            <tr>
                            <td><b>Staj Kabul Belgesi:</b></td>
                            </tr>
                            <tr>
                              <td colspan="4">
                                <?php
                                    $student_num = $row['ogrenci_okul_no'];
                                    $file_sql = "SELECT ogrenci_staj_kabul_belgesi FROM staj_kabul_belgesi WHERE ogrenci_numarasi='$student_num' AND staj_turu='staj1'";
                                    $file_result = mysqli_query($connection, $file_sql);
                                    if(mysqli_num_rows($file_result)== 0){
                                    ?>
                                        <div class="alert alert-danger" role="alert">Staj Kabul Belgesi Yüklenmemiştir!</div>
                                    <?php
                                    }else{
                                      while($file_row = mysqli_fetch_assoc($file_result)){
                                ?>
                                      <embed src="../../../Student/dashboard/Internship/uploads/<?php echo $file_row['ogrenci_staj_kabul_belgesi'] ?>" width="1100" height="400" type="application/pdf">
                                <?php
                                      }
                                    }
                                ?>
                              </td>
                            </tr>
                            <form action="./view-internship1-student-info.php" method="post">
                                <tr>
                                    <td colspan="3">
                                        <input name="feedback" type="text" class="form-control" placeholder="Öğrenci'ye geri Notification yaz" required>
                                    </td>
                                </tr>
                                <tr>
                                  <td>
                                      <?php
                                        $sql3 = "SELECT staj_durumu FROM Internship_Tracking WHERE ogrenci_numarasi='$student_number' AND staj_tur='staj1'";
                                        $res3 = mysqli_query($connection, $sql3);
                                        while($row3 = mysqli_fetch_assoc($res3)){
                                          if($row3['staj_durumu'] === 'degerlendirme'){
                                      ?>
                                      <!-- -------------------------------------------------- -->
                                      <button type="submit" name="staj-belge-yukleme-btn" value="<?php echo $student_num  ?>" class="btn btn-success">Öğrenci Staj Bitirme Belgelerini sisteme yüklesin</button>
                                      <!-- ---------------------------------------------------- -->
                                      <?php
                                          }else{
                                      ?>
                                            <button
                                            <?php
                                                if($row3['staj_durumu'] == 'onaylandi' || $row3['staj_durumu']=='belge_yuklenmesi'){
                                            ?>
                                              disabled
                                            <?php
                                                }
                                            ?>
                                            type="submit" name="staj-onayla-btn" value="<?php echo $student_num  ?>" class="btn btn-success">Staj Onayla</button>
                      
                                            <button
                                            <?php
                                                if($row3['staj_durumu'] == 'onaylandi'){
                                                  
                                                }else{
                                            ?>
                                                  disabled
                                            <?php
                                                }
                                            ?>
                                            type="submit" name="staj-degerlendirme-btn" value="<?php echo $student_num  ?>" class="btn btn-primary"
                                            >Staj'ı Değerlendirmeye Alın</button>
                                            
                                      <?php
                                          }
                                        }
                                      ?>
                                      <button type="submit" name="staj-red-btn" value="<?php echo $student_num  ?>" class="btn btn-outline-danger">Staj Red</button>
                                    </td>
                                </tr>
                            </form>
                            <?php
                                                    }
                                                }
                                            ?>
                    <?php
                        }
                    ?>
                    </form>
                </tbody>
            </table>
        </div>
    </div>
    <!-- 'done','devam_etmekte','degerlendirme','yeni_basvuru' -->
    <!-- -------------------------------------------------------------------------------------------------------------- -->
      <!-- Footer -->
      <footer class="footer">
        <div class="row align-items-center justify-content-xl-between">
          <div class="col-xl-6">
            <div class="copyright text-center text-xl-left text-muted">
              &copy; 2022 <a href="#" class="font-weight-bold ml-1">KOÜ Bilişim</a>
            </div>
          </div>
          <div class="col-xl-6">
            <ul class="nav nav-footer justify-content-center justify-content-xl-end">
              <li class="nav-item">
                <a href="#" class="nav-link">MIT License</a>
              </li>
            </ul>
          </div>
        </div>
      </footer>
    </div>
  </div>
  <!--   Core   -->
  <script src="../assets/js/plugins/jquery/dist/jquery.min.js"></script>
  <script src="../assets/js/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!--   Optional JS   -->
  <!--   Argon JS   -->
  <script src="../assets/js/argon-dashboard.min.js?v=1.1.2"></script>
  <script src="https://cdn.trackjs.com/agent/v3/latest/t.js"></script>
  <script>
    window.TrackJS &&
      TrackJS.install({
        token: "ee6fab19c5a04ac1a32a645abde4613a",
        application: "argon-dashboard-free"
      });
  </script>
</body>

</html>